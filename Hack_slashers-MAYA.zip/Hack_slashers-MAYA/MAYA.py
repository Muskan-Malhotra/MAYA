from playsound import playsound
from gtts import gTTS

import pyttsx3 #pip install pyttsx3
import speech_recognition as sr #pip install speechRecognition
import datetime
import wikipedia #pip install wikipedia
import webbrowser
import os
import smtplib

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[1].id)
engine.setProperty('voice', voices[1].id)


def speak(audio):
    engine.say(audio)
    engine.runAndWait()




def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good Morning!")

    elif hour>=12 and hour<18:
        speak("Good Afternoon!")

    else:
        speak("Good Evening!")

    speak("Hello I am Maya Sir. Please tell me how may I help you")

def takeCommand():
    #It takes microphone input from the user and returns string output

    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")

    except Exception as e:
        print(e)
        print("Say that again please...")
        return "None"
    return query

def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login('youremail@gmail.com', 'your-password')
    server.sendmail('youremail@gmail.com', to, content)
    server.close()

if __name__ == "__main__":
    wishMe()
    while True:
    # if 1:
        query = takeCommand().lower()

        # Logic for executing tasks based on query
        if 'wikipedia' in query:
            speak('Searching Wikipedia...')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak("According to Wikipedia")
            print(results)
            speak(results)

        elif 'open youtube' in query:
            webbrowser.open("youtube.com")

        elif 'open google' in query:
            webbrowser.open("google.com")

        elif 'open stackoverflow' in query:
            webbrowser.open("stackoverflow.com")


        #elif 'play music' in query:
        #    music_dir = "C:\\Users\\Aman Srivastava\\Desktop\\test_music.mp3"
        #    songs = os.listdir(music_dir)
        #    print(songs)
        #    os.startfile(os.path.join(music_dir, songs[0]))

        elif 'time' in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")
            speak(f"Sir, the time is {strTime}")

        elif 'open code' in query:
            codePath = "C:\\Users\\Haris\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
            os.startfile(codePath)

        #elif 'not feeling well' in query:
            #muspath = "C:\\Users\\Aman Srivastava\\Desktop\\mus"
            #os.startfile(mus)

        elif 'song'in query:
            speech=gTTS("Okay! Close your eyes and get deeper into the tunes..")
            speech.save("sirtunes1.mp3")
            playsound("sirtunes1.mp3")
            playsound("sooth.mp3")

        elif 'quotation' in query:
            speech=gTTS("Okay! Presenting Quotes by Sir APJ Abdul Kalam for you.")
            speech.save("sirquotes2.mp3")
            playsound("sirquotes2.mp3")
            playsound("apj_quotes.mp3")
        elif 'music' in query:
            speech=gTTS("Okay! Playing Music")
            speech.save("sirmusic3.mp3")
            playsound("sirmusic3.mp3")
            playsound("abc.mp3")
        elif 'mantra' in query:
            speech=gTTS("Om Shanti Shanti Shanti ")
            speech.save("sirmusic4.mp3")
            playsound("sirmusic4.mp3")
            playsound("mantras.mp3")
        elif 'laughing' in query:
            speech=gTTS("Now hold your breathe for 2 seconds and laugh after me. Let's Begin")
            speech.save("sirmusic5.mp3")
            playsound("sirmusic5.mp3")
            playsound("laugh.mp3")
        elif 'yoga'in query:
            speech=gTTS("Okay! Let's Begin...Yoga is an extreme stress-relief excercise, involves a series of moving and stationary poses, or postures, combined with deep breathing. A mind body excercise, yoga can strengthen your body's natural relaxation response and bring you into a healathy balance. The most versatile form of yoga for stress management is power yoga. Power yoga consists of postures like first balaasan, second uttanasana, third shavasan, and last sukhasan.")
            speech.save("yoga.mp3")
            playsound("yoga.mp3")

        elif 'breathing' in query:
            speech=gTTS("Okay! Let's Begin... close your eyes take a deep breathe again inhale and exhale.  again do the same. now start holding your inhaled breathe. feel the oxygen exchange. feel your body feel your soul feel your breathe. remind your achivements. remind your strength. recall the name of your loved ones repeate the same for next 5 minutes ")
            speech.save("oxygen.mp3")
            playsound("oxygen.mp3")
        elif 'speaker'in query:
            playsound("thoughts.mp3")
        elif 'help' in query:
            speech=gTTS("Wait! while we are connecting to Dr. Rahul Chandhok")
            speech.save("sirdoctor.mp3")
            playsound("sirdoctor.mp3")
            playsound("help.mp3")
        elif 'task' in query:
            speech=gTTS("Keep a pen and paper with you to start this activity. Write whatever makes you tensed in that paper. and now just tear that paper in exact 12 pieces  breathe in and breathe out ")
            speech.save("heat.mp3")
            playsound("heat.mp3")

        #Psychatarist

        '''elif 'email to abhishek' in query:
            try:
                speak("What should I say?")
                content = takeCommand()
                to = "abhishek.saini1410@gmail.com"
                sendEmail(to, content)
                speak("Email has been sent!")
            except Exception as e:
            #    print(e)
                speak("Sorry my friend. I am not able to send this email")'''
